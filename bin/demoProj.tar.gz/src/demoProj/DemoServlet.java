package demoProj;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DemoServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3146486870152830705L;

	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		System.out.println("into Servlet!!");
		System.out.println(System.getProperty("user.dir"));
		Properties prop = new Properties();     
		//读取属性文件a.properties
		//InputStream in = new BufferedInputStream (new FileInputStream(new File("D:\\workspace\\demoProj\\config\\demodb.properties")));
		URL path = this.getClass().getClassLoader().getResource("/");
		InputStream in = new BufferedInputStream (new FileInputStream(new File(path.getPath() + "config/demodb.properties")));
		prop.load(in);
		String dbUser = prop.getProperty("MYSQL_USER");//"root";
		String dbPassword = prop.getProperty("MYSQL_PASSWORD");//"123456";
		String dbAddr = prop.getProperty("MYSQL_ADDR");//"127.0.0.1:3306";
		String dbName = prop.getProperty("MYSQL_NAME");//"demo";

		in.close();
		
		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://" + dbAddr + "/" + dbName + "?user=" + dbUser + "&password=" + dbPassword);// localhost:主机名，端口号；Garbage:数据库database；Mysql帐户、密码
			// 获取支持sql的statement
			Statement st = conn.createStatement();
			// 根据写的sql语句查询结果到ResultSet集合中去
			String sql = "SELECT * FROM demo_data";
			ResultSet set = st.executeQuery(sql);
			PrintWriter pw = response.getWriter();
			// 定义一个表头
			InetAddress netAddress = getInetAddress();
			pw.println("<table><tr>"
					+ "<td>Host IP</td>"
					+ "<td>" + getHostIp(netAddress) + "</td></tr>"
					+ "<tr><td>Host Name</td>"
					+ "<td>" + getHostName(netAddress) + "</td></tr>"
					+ "<tr><td>Database Address</td>"
					+ "<td>" + dbAddr + "</td>"
					+ "</tr></table><br>");
			pw.println("<table><tr>"
					+ "<td>Employee No.</td>"
					+ "<td>Birth Date</td>"
					+ "<td>First Name</td>"
					+ "<td>Last Name</td>"
					+ "<td>Gender</td>"
					+ "<td>Hire Date</td>"
					+ "</tr>");
			while (set.next()) {
				int empNo = set.getInt(1);
				String birthDate = set.getString(2);
				String firstName = set.getString(3);
				String lastName = set.getString(4);
				String gender = set.getString(5);
				String hireDate = set.getString(6);
				pw.println("<tr>"
						+ "<td>" + empNo + "</td>"
						+ "<td>" + birthDate + "</td>"
						+ "<td>" + firstName + "</td>" 
						+ "<td>" + lastName + "</td>" 
						+ "<td>" + gender + "</td>" 
						+ "<td>" + hireDate + "</td>" 
						+ "<tr>");
			}
			pw.println("</table>");
			pw.close();
			set.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
  
    public static InetAddress getInetAddress(){  
  
        try{  
            return InetAddress.getLocalHost();  
        }catch(UnknownHostException e){  
            System.out.println("unknown host!");  
        }  
        return null;  
  
    }  
  
    public static String getHostIp(InetAddress netAddress){  
        if(null == netAddress){  
            return null;  
        }  
        String ip = netAddress.getHostAddress(); //get the ip address  
        return ip;  
    }  
  
    public static String getHostName(InetAddress netAddress){  
        if(null == netAddress){  
            return null;  
        }  
        String name = netAddress.getHostName(); //get the host address  
        return name;  
    } 
}
